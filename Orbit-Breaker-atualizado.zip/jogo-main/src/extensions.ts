export type OrbitExtensionSettings = {
  smoothCamera: boolean;
  meteorRadar: boolean;
};

export const ORBIT_EXTENSIONS = {
  cameraFollow: { id: 'camera-follow', label: 'Câmera suave' },
  meteorRadar: { id: 'meteor-radar', label: 'Radar de meteoros' },
  raidLoader: { id: 'raid-loader', label: 'Transição entre raids' },
} as const;

export const DEFAULT_EXTENSION_SETTINGS: OrbitExtensionSettings = {
  smoothCamera: true,
  meteorRadar: true,
};

const STORAGE_KEY = 'orbit-breaker-extension-settings';

export function loadExtensionSettings(): OrbitExtensionSettings {
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null') as Partial<OrbitExtensionSettings> | null;
    return {
      smoothCamera: stored?.smoothCamera ?? DEFAULT_EXTENSION_SETTINGS.smoothCamera,
      meteorRadar: stored?.meteorRadar ?? DEFAULT_EXTENSION_SETTINGS.meteorRadar,
    };
  } catch {
    return { ...DEFAULT_EXTENSION_SETTINGS };
  }
}

export function saveExtensionSettings(settings: OrbitExtensionSettings) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
}

export const WORLD_SCALE = {
  width: 2.15,
  height: 2,
} as const;

export const CAMERA = {
  smoothLerp: 0.085,
  snapDistance: 20,
} as const;

export const RAID_TRANSITION_MS = 1500;
