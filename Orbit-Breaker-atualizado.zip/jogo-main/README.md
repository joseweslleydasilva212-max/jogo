# Orbit Breaker

Arcade espacial feito com Phaser 3 + Vite + TypeScript. Pilote a nave, destrua meteoros e sobreviva a raids cada vez maiores.

## Executar

```sh
npm install
npm run dev
```

## Controles

- `W` ou `↑`: acelerar
- `A` / `D` ou `←` / `→`: girar
- `Espaço`: disparar
- `E`: habilidade
- `P`: pausar ou retomar
- Celular: use os controles na tela

## Recursos

- Campo de jogo ampliado para aproximadamente 80% da largura da tela em desktop.
- Mundo de jogo maior com câmera seguindo a nave suavemente.
- Radar com setas vermelhas apontando para todos os meteoros ativos.
- Barra de carregamento animada entre raids/ondas.
- Lobby de seleção de nave com botão **JOGAR** ligado diretamente à nave escolhida.
- Botão **CONFIGURAÇÕES** com extensões ativáveis e arquitetura preparada para novos ajustes.
- Recorde salvo localmente neste navegador.

Os novos recursos configuráveis ficam centralizados em `src/extensions.ts`, enquanto o núcleo da cena continua em `src/game.ts`.
Para verificar a versão de produção, rode `npm run build`.
